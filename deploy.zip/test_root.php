<?php
// Root Level Test
echo "<h1>Root PHP is Working</h1>";
echo "Current Dir: " . __DIR__;
